﻿public enum Lights
{
	Red,
	Green,
	Yellow
}
