﻿using CreateCustomClassAttribute;

namespace CreateCustomClassAttribute
{
	[Custom]
	class Weapon
	{
	}
}
