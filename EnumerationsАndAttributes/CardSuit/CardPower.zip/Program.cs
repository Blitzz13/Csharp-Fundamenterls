﻿using System;

namespace CardSuit
{
	class Program
	{
		static void Main(string[] args)
		{
			string cardRank = Console.ReadLine();

			string cardSuit = Console.ReadLine();

			Console.WriteLine($"Card name: {cardRank} of {cardSuit}; Card power: {(int)Enum.Parse(typeof(CardRank),cardRank) + (int)Enum.Parse(typeof(CardTypes), cardSuit)}");
		}
	}
}
