﻿using System;

class Card : IComparable<Card>
{
	private string _cardRankInput;
	private string _cardSuitInput;

	public int Power => GetCardPower();

	public string CardSuitInput
	{
		get { return _cardSuitInput; }
		set { _cardSuitInput = value; }
	}

	public string CardRankInput
	{
		get { return _cardRankInput; }
		set { _cardRankInput = value; }
	}

	public Card(string cardRank, string cardSuit)
	{
		_cardRankInput = cardRank;
		_cardSuitInput = cardSuit;
	}

	public override string ToString()
	{
		int cardPower = GetCardPower();
		return $@"Card name: {this.CardRankInput} of {this.CardSuitInput}; Card power: {cardPower}";
	}

	private int GetCardPower()
	{
		return (int)Enum.Parse(typeof(Rank), this.CardRankInput) +
									(int)Enum.Parse(typeof(Suit), this.CardSuitInput);
	}

	public int CompareTo(Card other)
	{
		if (ReferenceEquals(this, other))
		{
			return 0;
		}

		if (ReferenceEquals(null, other))
		{
			return 1;
		}

		var cardRankInputComparison = string.Compare(_cardRankInput, other._cardRankInput, StringComparison.Ordinal);
		if (cardRankInputComparison != 0)
		{
			return cardRankInputComparison;
		}

		return string.Compare(_cardSuitInput, other._cardSuitInput, StringComparison.Ordinal);
	}
}
