﻿public enum CardTypes
{
	Clubs,
	Diamonds,
	Hearts,
	Spades
}