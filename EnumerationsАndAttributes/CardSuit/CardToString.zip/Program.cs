﻿using System;

namespace CardSuit
{
	class Program
	{
		static void Main()
		{
			string cardRank = Console.ReadLine();
			string cardSuit = Console.ReadLine();
			Card card = new Card(cardRank, cardSuit);
			Console.WriteLine(card);
		}
	}
}
