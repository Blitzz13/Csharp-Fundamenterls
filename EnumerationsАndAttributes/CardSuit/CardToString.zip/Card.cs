﻿using System;

namespace CardSuit
{
	class Card
	{
		private string _cardRankInput;
		private string _cardSuitInput;

		public string CardSuitInput
		{
			get { return _cardSuitInput; }
			set { _cardSuitInput = value; }
		}

		public string CardRankInput
		{
			get { return _cardRankInput; }
			set { _cardRankInput = value; }
		}
		
		public Card(string cardRank, string cardSuit)
		{
			_cardRankInput = cardRank;
			_cardSuitInput = cardSuit;
		}

		public enum CardRank
		{
			Ace = 14,
			Two = 2,
			Three = 3,
			Four = 4,
			Five = 5,
			Six = 6,
			Seven = 7,
			Eight = 8,
			Nine = 9,
			Ten = 10,
			Jack = 11,
			Queen = 12,
			King = 13
		}

		public enum CardTypes
		{
			Clubs = 0,
			Diamonds = 13,
			Hearts = 26,
			Spades = 39
		}

		public override string ToString()
		{
			return $@"Card name: {this.CardRankInput} of {this.CardSuitInput}; Card power: {
					(int) Enum.Parse(typeof(Card.CardRank), this.CardRankInput) +
					(int) Enum.Parse(typeof(Card.CardTypes), this.CardSuitInput)
				}";
		}
	}
}
