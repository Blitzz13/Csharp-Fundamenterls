﻿using System;

namespace CardSuit
{
	class Program
	{
		static void Main(string[] args)
		{
			//string 
			Console.WriteLine("Card Suits: ");

			foreach (var cardType in Enum.GetValues(typeof(CardTypes)))
			{
				Console.WriteLine($"Ordinal value: {(int)cardType}; Name value: {cardType}");
			}
		}
	}
}
