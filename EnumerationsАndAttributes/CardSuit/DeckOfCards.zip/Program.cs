﻿using System;

class Program
{
	static void Main()
	{
		PrintAllCardsFromDeck();
	}

	private static void GetInput()
	{
		string input = Console.ReadLine();

		if (input == "Rank")
		{
			PrintAttribute(typeof(Rank));
		}
		else
		{
			PrintAttribute(typeof(Suit));
		}
	}

	private static void PrintAttribute(Type type)
	{
		var attributes = type.GetCustomAttributes(false);
		Console.WriteLine(attributes[0]);
	}

	private static void PrintAllCardsFromDeck()
	{
		foreach (var suit in Enum.GetNames(typeof(Suit)))
		{
			foreach (var rank in Enum.GetNames(typeof(Rank)))
			{
				Console.WriteLine($"{rank} of {suit}");
			}
		}
	}
}