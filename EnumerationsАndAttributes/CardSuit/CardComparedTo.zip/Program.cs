﻿using System;

namespace CardSuit
{
	class Program
	{
		static void Main()
		{
			string cardRank1 = Console.ReadLine();
			string cardSuit1 = Console.ReadLine();
			string cardRank2 = Console.ReadLine();
			string cardSuit2 = Console.ReadLine();
			Card card1 = new Card(cardRank1, cardSuit1);
			Card card2 = new Card(cardRank2, cardSuit2);
			int greaterCardPower = card1.CompareTo(card2);

			if (greaterCardPower == card1.Power)
			{
				Console.WriteLine(card1);
			}
			else
			{
				Console.WriteLine(card2);
			}
		}
	}
}