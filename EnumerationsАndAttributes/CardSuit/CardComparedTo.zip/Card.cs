﻿using System;

namespace CardSuit
{
	class Card : IComparable<Card>
	{
		private string _cardRankInput;
		private string _cardSuitInput;

		public int Power => GetCardPower();

		public string CardSuitInput
		{
			get { return _cardSuitInput; }
			set { _cardSuitInput = value; }
		}

		public string CardRankInput
		{
			get { return _cardRankInput; }
			set { _cardRankInput = value; }
		}

		public Card(string cardRank, string cardSuit)
		{
			_cardRankInput = cardRank;
			_cardSuitInput = cardSuit;
		}

		public enum CardRank
		{
			Ace = 14,
			Two = 2,
			Three = 3,
			Four = 4,
			Five = 5,
			Six = 6,
			Seven = 7,
			Eight = 8,
			Nine = 9,
			Ten = 10,
			Jack = 11,
			Queen = 12,
			King = 13
		}

		public enum CardTypes
		{
			Clubs = 0,
			Diamonds = 13,
			Hearts = 26,
			Spades = 39
		}

		public int CompareTo(Card otherCard)
		{
			if (this.Power > otherCard.Power)
			{
				return this.Power - otherCard.Power;
			}

			if (this.Power < otherCard.Power)
			{
				return otherCard.Power - this.Power;
			}

			return 0;
		}

		public override string ToString()
		{
			int cardPower = GetCardPower();
			return $@"Card name: {this.CardRankInput} of {this.CardSuitInput}; Card power: {cardPower}";
		}

		private int GetCardPower()
		{
			return (int)Enum.Parse(typeof(Card.CardRank), this.CardRankInput) +
										(int)Enum.Parse(typeof(Card.CardTypes), this.CardSuitInput);
		}

	}
}
