﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace GenericBox
{
	class Program
	{
		static void Main(string[] args)
		{
			int n = int.Parse(Console.ReadLine());
			IList<Box<string>> listOfBoxes = new List<Box<string>>();
			for (int i = 0; i < n; i++)
			{
				Box<string> strBox = new Box<string>(Console.ReadLine());
				listOfBoxes.Add(strBox);
			}

			string element = Console.ReadLine();
			int result = GetGreaterElementCout(listOfBoxes, element);
			Console.WriteLine(result);
		}

		private static void SwapElements<T>(IList<T> listOfBoxes, int index1, int index2)
		{
			T tempElement = listOfBoxes[index1];
			listOfBoxes[index1] = listOfBoxes[index2];
			listOfBoxes[index2] = tempElement;
		}

		private static int GetGreaterElementCout<T>(IList<Box<string>> listOfBoxes, T element)
			where T : IComparable<T>
		{
			int result = listOfBoxes.Count(b => b.Value.CompareTo(element) > 0);
			return result;
		}
	}
}
