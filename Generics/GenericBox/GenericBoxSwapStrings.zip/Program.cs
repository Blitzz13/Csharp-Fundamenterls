﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace GenericBox
{
	class Program
	{
		static void Main(string[] args)
		{
			int n = int.Parse(Console.ReadLine());
			IList<Box<string>> listOfBoxes = new List<Box<string>>();
			for (int i = 0; i < n; i++)
			{
				Box<string> strBox = new Box<string>(Console.ReadLine());
				listOfBoxes.Add(strBox);
			}

			int[] indexes = Console.ReadLine().Split().Select(int.Parse).ToArray();
			SwapElements(listOfBoxes, indexes[0], indexes[1]);

			foreach (var box in listOfBoxes)
			{
				Console.WriteLine(box);
			}
		}

		private static void SwapElements<T>(IList<T> listOfBoxes, int index1, int index2)
		{
			T tempElement = listOfBoxes[index1];
			listOfBoxes[index1] = listOfBoxes[index2];
			listOfBoxes[index2] = tempElement;
		}
	}
}
