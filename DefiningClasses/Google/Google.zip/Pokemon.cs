﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


class Pokemon
{
    public string PokeName { get; set; }
    public string PokeType { get; set; }
}

