﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


class Company
{
    public string CompanyName { get; set; }
    public string Department { get; set; }
    public double Salary { get; set; }
}

