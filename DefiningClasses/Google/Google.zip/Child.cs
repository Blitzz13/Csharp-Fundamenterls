﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class Child
{
    public string childName { get; set; }
    public string childBirthday { get; set; }
}
