﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DefineAnInterface
{
	interface IBirthable
	{
		string Birthdate { get; set; }
	}
}
