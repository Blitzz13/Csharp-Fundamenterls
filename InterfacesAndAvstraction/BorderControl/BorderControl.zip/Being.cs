﻿class Being
{
	public Being(string id)
	{
		this.Id = id;
	}

	public string Id { get; set; }
}