﻿namespace Telephony
{
	interface ICallable
	{
		string Call(string number);
	}

}
