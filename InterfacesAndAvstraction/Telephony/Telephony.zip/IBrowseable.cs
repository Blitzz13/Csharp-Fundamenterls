﻿namespace Telephony
{
	interface IBrowseable
	{
		string Browse(string url);
	}

}
