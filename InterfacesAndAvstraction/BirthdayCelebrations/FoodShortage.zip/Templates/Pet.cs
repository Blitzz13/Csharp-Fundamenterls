﻿namespace BirthdayCelebrations
{
	class Pet : Being
	{
		public Pet(string name, string birthDate)
		{
			this.Name = name;
			this.BirthDate = birthDate;
		}

	}
}