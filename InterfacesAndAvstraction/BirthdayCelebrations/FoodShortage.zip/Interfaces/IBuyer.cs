﻿namespace BirthdayCelebrations
{
	interface IBuyer
	{
		int Food { get; set; }

		void BuyFood();
	}
}
