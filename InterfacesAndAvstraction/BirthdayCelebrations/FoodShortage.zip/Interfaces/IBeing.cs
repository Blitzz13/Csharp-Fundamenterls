﻿namespace BirthdayCelebrations
{
	interface IBeing
	{
		string Id { get; set; }
	}
}