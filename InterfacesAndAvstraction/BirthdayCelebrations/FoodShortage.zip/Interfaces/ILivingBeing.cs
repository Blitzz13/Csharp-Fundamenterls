﻿interface ILivingBeing
{
	string Name { get; set; }
	string BirthDate { get; set; }
}